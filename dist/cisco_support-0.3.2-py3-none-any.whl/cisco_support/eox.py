import requests
from . import auth

class EoX:
    def __init__(self, client_id, client_secret):
        self.access_token = auth.generate_access_token(client_id, client_secret)
        self.base_url = "https://apix.cisco.com/supporttools/eox/rest/5"

    def get_by_dates(self, start_date, end_date, pageIndex=1):
        url = f"{self.base_url}/EOXByDates/{pageIndex}/{start_date}/{end_date}?responseencoding=json"
        headers = {
            'Authorization': f'Bearer {self.access_token}'
        }

        response = requests.get(url, headers=headers)
        return response.json()

    def get_by_product_ids(self, product_ids, pageIndex=1):
        url = f"{self.base_url}/EOXByProductID/{pageIndex}/{','.join(product_ids)}?responseencoding=json"
        headers = {
            'Authorization': f'Bearer {self.access_token}'
        }

        response = requests.get(url, headers=headers)
        return response.json()

    def get_by_serial_numbers(self, serial_numbers, pageIndex=1):
        url = f"{self.base_url}/EOXBySerialNumber/{pageIndex}/{','.join(serial_numbers)}?responseencoding=json"
        headers = {
            'Authorization': f'Bearer {self.access_token}'
        }

        response = requests.get(url, headers=headers)
        return response.json()

    def get_by_software_release_strings(self, softwares, pageIndex=1):
        sw = []
        for i, software in enumerate(softwares):
            sw.append(f"input{i+1}={software}")
        url = f"{self.base_url}/EOXBySWReleaseString/{pageIndex}?{'&'.join(sw)}&responseencoding=json"
        headers = {
            'Authorization': f'Bearer {self.access_token}'
        }

        response = requests.get(url, headers=headers)
        return response.json()